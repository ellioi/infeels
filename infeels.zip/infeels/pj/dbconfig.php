<?php

$servername = 'localhost'; // tietokannan web-osoite/host/server
$dbname = 'peliohje'; // tietokannan nimi
$username = 'root'; // tietokannan käyttäjätunnus
$password = 'salasana'; // tietokannan salasana

$potaulukko = 'peliohjeet'; // peliohjetaulukon nimi
 
?>